Gridlee
(c) 1982, Videa

These ROMs were dumped from the only known existing prototype, owned by
Dale Luck.

Permission to redistribute these ROMs freely, for non-commercial use in
the MAME emulator, has been granted by the original owners: Howard Delman,
Roger Hector, and Ed Rotberg.

Below is a copy of the final email from Dale.

> From: Dale Luck <DLuck@xxxxxxxx.com>
> To: agiles@mame.net
> Subject: RE: Forwarded message
> Date: Fri, 27 Apr 2001 19:31:08 -0700
>
> Hello Aaron,
> I've received email from Roger, Ed, and Howard giving permission to use the
> roms. I've sent the ok to Al to release them to you. Good luck, have fun.
> Remember that commercial use of the rom contents is prohibited, and each of
> the fellows would like a copy of the final work so they can finally play
> Gridlee themselves.
> Thanks a bunch.
> I know its going to be a pretty big job.
> Dale Luck

